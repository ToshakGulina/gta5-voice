import torch
from torch import nn, arange, stack, cat, is_tensor

class RotaryEmbedding(nn.Module):
    def __init__(
        self,
        dim,
        use_xpos=False,
        scale_base=512,
        interpolation_factor=1.0,
        base=10000,
        base_rescale_factor=1.0,
    ):
        super().__init__()
        base *= base_rescale_factor ** (dim / (dim - 2))
        inv_freq = 1.0 / (base ** (arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv_freq)
        self.interpolation_factor = interpolation_factor
        if not use_xpos:
            self.register_buffer("scale", None)
            return
        scale = (arange(0, dim, 2) + 0.4 * dim) / (1.4 * dim)
        self.scale_base = scale_base
        self.register_buffer("scale", scale)

    def forward_from_seq_len(self, seq_len):
        device = self.inv_freq.device
        t = arange(seq_len, device=device)
        return self.forward(t)

    @torch.amp.autocast("cuda", enabled=False)
    def forward(self, t, offset=0):
        max_pos = t.max() + 1
        if t.ndim == 1:
            t = t.unsqueeze(0)
        freqs = torch.einsum("b i , j -> b i j", t.type_as(self.inv_freq), self.inv_freq) / self.interpolation_factor
        freqs = stack((freqs, freqs), dim=-1)
        freqs = freqs.reshape(*freqs.shape[:-2], -1)
        if self.scale is None:
            return freqs, 1.0
        power = (t - (max_pos // 2)) / self.scale_base
        scale = self.scale ** power.unsqueeze(-1)
        scale = stack((scale, scale), dim=-1)
        scale = scale.reshape(*scale.shape[:-2], -1)
        return freqs, scale

def rotate_half(x):
    x = x.reshape(*x.shape[:-1], -1, 2)
    x1, x2 = x.unbind(dim=-1)
    x = stack((-x2, x1), dim=-1)
    return x.reshape(*x.shape[:-2], -1)

@torch.amp.autocast("cuda", enabled=False)
def apply_rotary_pos_emb(t, freqs, scale=1):
    rot_dim, seq_len, orig_dtype = freqs.shape[-1], t.shape[-2], t.dtype
    freqs = freqs[:, -seq_len:, :]
    scale = scale[:, -seq_len:, :] if is_tensor(scale) else scale
    if t.ndim == 4 and freqs.ndim == 3:
        freqs = freqs.unsqueeze(1)
        if is_tensor(scale):
            scale = scale.unsqueeze(1)
    t, t_unrotated = t[..., :rot_dim], t[..., rot_dim:]
    t = (t * freqs.cos() * scale) + (rotate_half(t) * freqs.sin() * scale)
    out = cat((t, t_unrotated), dim=-1)
    return out.type(orig_dtype)
