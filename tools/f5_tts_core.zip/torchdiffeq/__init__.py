import torch

def odeint(fn, y0, t, method="euler", **kwargs):
    y = y0
    out = [y]
    for i in range(len(t) - 1):
        t0 = t[i]
        t1 = t[i + 1]
        dt = t1 - t0
        if method == "midpoint":
            k1 = fn(t0, y)
            k2 = fn(t0 + 0.5 * dt, y + 0.5 * dt * k1)
            y = y + dt * k2
        else:
            y = y + dt * fn(t0, y)
        out.append(y)
    return torch.stack(out, dim=0)
