from f5_tts.model.backbones.dit import DiT
__all__ = ['DiT']
